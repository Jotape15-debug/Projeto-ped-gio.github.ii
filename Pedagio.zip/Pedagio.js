// Constantes
const DISTANCIA = 120; // Distância em km
const VALOR_PEDAGIO = 20; // Valor do pedágio

let registros = [];
let inicioProcesso = null;
let finalProcesso = null;

// Função para registrar veículo
document.getElementById('registroForm').onsubmit = function(event) {
    event.preventDefault(); // Previne o envio do formulário

    const placa = document.getElementById('placa').value;
    const horaEntrada = document.getElementById('horaEntrada').value;
    const horaSaida = document.getElementById('horaSaida').value;

    // Calcula o tempo em horas
    const tempoGasto = calcularTempo(horaEntrada, horaSaida);
    const velocidadeMedia = calcularVelocidade(tempoGasto);
    const valorPago = calcularValorPago(velocidadeMedia);
    
    // Registra os dados
    registros.push({ placa, horaEntrada, horaSaida, tempoGasto, velocidadeMedia, valorPago });
    
    // Atualiza o relatório
    atualizarRelatorio(placa, horaEntrada, horaSaida, tempoGasto, velocidadeMedia, valorPago);

    // Atualiza os tempos de processamento
    if (!inicioProcesso) {
        inicioProcesso = horaEntrada;
    }
    finalProcesso = horaSaida;

    // Limpa o formulário
    document.getElementById('registroForm').reset();
};

// Função para calcular o tempo em horas
function calcularTempo(horaEntrada, horaSaida) {
    const [hEntrada, mEntrada] = horaEntrada.split(':').map(Number);
    const [hSaida, mSaida] = horaSaida.split(':').map(Number);
    
    const entradaEmMinutos = hEntrada * 60 + mEntrada;
    const saidaEmMinutos = hSaida * 60 + mSaida;

    return (saidaEmMinutos - entradaEmMinutos) / 60; // Retorna em horas
}

// Função para calcular a velocidade média
function calcularVelocidade(tempoGasto) {
    return DISTANCIA / tempoGasto; // km/h
}

// Função para calcular o valor a pagar
function calcularValorPago(velocidadeMedia) {
    let desconto = 0;

    if (velocidadeMedia <= 60) {
        desconto = 0.15;
    } else if (velocidadeMedia <= 100) {
        desconto = 0.10;
    }

    return VALOR_PEDAGIO * (1 - desconto);
}

// Função para atualizar a tabela e relatório
function atualizarRelatorio(placa, horaEntrada, horaSaida, tempoGasto, velocidadeMedia, valorPago) {
    const tbody = document.querySelector('#registrosTable tbody');
    const tr = document.createElement('tr');
    
    tr.innerHTML = `
        <td>${placa}</td>
        <td>${horaEntrada}</td>
        <td>${horaSaida}</td>
        <td>${tempoGasto.toFixed(2)}</td>
        <td>${velocidadeMedia.toFixed(2)}</td>
        <td>${valorPago.toFixed(2)}</td>
    `;
    
    tbody.appendChild(tr);
    
    // Atualiza relatório de turno
    atualizarRelatorioTurno();
}

// Função para atualizar o relatório do turno
function atualizarRelatorioTurno() {
    if (registros.length === 0) return;

    const velocidades = registros.map(r => r.velocidadeMedia);
    const totalValores = registros.reduce((acc, r) => acc + r.valorPago, 0);
    
    const menorVelocidade = Math.min(...velocidades);
    const maiorVelocidade = Math.max(...velocidades);
    const mediaVelocidade = totalValores / velocidades.length;

    document.getElementById('relatorio').innerHTML = `
        <p>Menor Velocidade: ${menorVelocidade.toFixed(2)} km/h</p>
        <p>Maior Velocidade: ${maiorVelocidade.toFixed(2)} km/h</p>
        <p>Média das Velocidades: ${mediaVelocidade.toFixed(2)} km/h</p>
        <p>Total de Valores: R$ ${totalValores.toFixed(2)}</p>
        <p>Hora de Início: ${inicioProcesso}</p>
        <p>Hora de Final: ${finalProcesso}</p>
    `;
}
